#!/bin/bash

# Читаем файл email_list.txt
while IFS= read -r email; do
  # Отправляем почтовое уведомление
  echo "Тестовое уведомление" | mail -s "Тестовое уведомление" $email
done < email_list.txt

echo "Почтовые уведомления отправлены."
