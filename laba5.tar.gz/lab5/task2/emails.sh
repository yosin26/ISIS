#!/bin/bash

# Создаем файл email_list.txt
> email_list.txt

# Читаем файл /etc/passwd и фильтруем пользователей с GID > 100
awk -F: '$4 > 100 {print $1"@sibstrin.ru"}' /etc/passwd >> email_list.txt

echo "Список e-mail пользователей системы записан в файл email_list.txt."
