#!/bin/bash

# Файл журналирования
log_file="journal.log"

# Файл для хранения суммарного времени
output_file="summary_time.txt"

# Очищаем файл перед записью
> "$output_file"

# Используем awk для суммирования времени по бригадам
awk -F', ' '
{
    # Суммируем время для каждой бригады
    time[$1] += $2
}
END {
    # Печатаем результат
    for (brigade in time) {
        print brigade, time[brigade]
    }
}
' "$log_file" | sort -k2,2nr > "$output_file"

echo "Суммарное процессорное время для каждой бригады записано в файл $output_file."
