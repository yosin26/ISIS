#!/bin/bash

# Файл для хранения пользователей, ни разу не входивших в систему
output_file="never_logged_in_users.txt"

# Очищаем файл перед записью
> "$output_file"

# Получаем список всех пользователей
all_users=$(cut -d: -f1 /etc/passwd)

# Получаем список пользователей, которые когда-либо входили в систему
logged_in_users=$(last | awk '{print $1}' | sort | uniq)

# Перебираем всех пользователей и проверяем, входили ли они в систему
for user in $all_users; do
    if ! echo "$logged_in_users" | grep -q "^$user$"; then
        echo "$user" >> "$output_file"
    fi
done

echo "Список пользователей, ни разу не входивших в систему, записан в файл $output_file."
