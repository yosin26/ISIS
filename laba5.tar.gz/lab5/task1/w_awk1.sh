#!/bin/bash

# Проверяем, существует ли файл /var/log/wtmp
if [[ ! -f /var/log/wtmp ]]; then
    echo "Файл /var/log/wtmp не найден!"
    exit 1
fi

# Создаем файл w-awk и записываем заголовок
{
    echo -e "Пользователь\tВремя входа\tВремя выхода\tВремя работы"
    
    # Обработка файла wtmp с помощью last
    last -F -w | awk '
    {
        user = $1
        login_time = $4 " " $5 " " $6
        logout_time = $8 " " $9 " " $10
        work_time = "N/A"  # Замените на логику расчета времени работы
        print user "\t" login_time "\t" logout_time "\t" work_time
    }
    ' 
} > w-awk

echo "Информация записана в файл w-awk."
