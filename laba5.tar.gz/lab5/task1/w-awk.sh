#!/bin/sh

# Проверяем, существует ли файл /var/log/wtmp
if [[ ! -f /var/log/wtmp ]]; then
    echo "Файл /var/log/wtmp не найден!"
    exit 1
fi

# Создаем файл w-awk и записываем заголовок
{
    echo -e "Пользователь\tВремя входа\t\tВремя выхода\t\tВремя работы"
    
    # Обработка файла wtmp с помощью last
    last -F -w | awk '
    {
        if (NF > 10) {  # Проверяем, что строка содержит достаточно полей
            user = $1
            login_time = $4 " " $5 " " $6 " " $7
            logout_time = ($8 == "still") ? "N/A" : $8 " " $9 " " $10 " " $11
            work_time = "N/A"  # Здесь можно добавить логику для расчета времени работы
            print user "\t" login_time "\t" logout_time "\t" work_time
        }
    }
    ' 
} > w-awk

echo "Информация записана в файл w-awk."
