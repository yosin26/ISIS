#!/bin/bash

# Файл журналирования
log_file="journal.log"

# Студент, для которого нужно рассчитать суммарное время
student="student1"

# Массив для хранения суммарного времени по месяцам
declare -A monthly_time

# Чтение файла и обработка данных
while IFS=', ' read -r date username time; do
    # Проверка на соответствие студенту и на диапазон дат
    if [[ "$username" == "$student" ]] && [[ "$date" > "2023-08-31" ]] && [[ "$date" < "2024-01-01" ]]; then
        month=$(date -d "$date" +%Y-%m) # Получаем год и месяц
        monthly_time[$month]=$(echo "${monthly_time[$month]:-0} + $time" | bc)
    fi
done < "$log_file"

# Вывод результатов
echo "Суммарное процессорное время за день для студента $student с сентября по декабрь:"
for month in "${!monthly_time[@]}"; do
    echo "$month: ${monthly_time[$month]}"
done
