#!/bin/bash

# Проверка наличия файла
file="u-mes"

if [[ ! -f "$file" ]]; then
    echo "Файл $file не найден!"
    exit 1
fi

# Подсчет объема принятой и переданной информации
awk '
{
    # Ищем строки с информацией о принятии и передаче данных
    if ($3 == "received") {
        received[$2] += $4;  # Суммируем объем принятой информации
    } else if ($3 == "sent") {
        sent[$2] += $4;  # Суммируем объем переданной информации
    }
}

END {
    # Выводим результаты
    print "Пользователь\tПринято (bytes)\tПередано (bytes)";
    for (user in received) {
        printf "%s\t%d\t%d\n", user, received[user], (user in sent ? sent[user] : 0);
    }
    for (user in sent) {
        if (!(user in received)) {
            printf "%s\t0\t%d\n", user, sent[user];
        }
    }
}
' "$file"
