#!/bin/bash

# Файл со списком пользователей
user_list="u1-list"

# Проверка наличия файла
if [[ ! -f "$user_list" ]]; then
    echo "Файл $user_list не найден!"
    exit 1
fi

# Ассоциативный массив для подсчета пользователей в группах
declare -A group_count

# Чтение файла со списком пользователей
while IFS= read -r user; do
    # Получаем группы пользователя
    groups_output=$(groups "$user" 2>/dev/null)
    
    # Проверяем, что команды успешно выполнены
    if [[ $? -eq 0 ]]; then
        # Извлекаем имя группы из вывода
        for group in $groups_output; do
            if [[ "$group" != "$user:" ]]; then
                ((group_count[$group]++))
            fi
        done
    fi
done < "$user_list"

# Вывод результатов
echo "Группы и количество пользователей в них (по убыванию):"
for group in "${!group_count[@]}"; do
    echo "$group: ${group_count[$group]}"
done | sort -t: -k2 -nr
