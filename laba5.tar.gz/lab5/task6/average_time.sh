#!/bin/bash

# Файл журналирования
log_file="journal.log"

# Пользователь, для которого нужно рассчитать среднее время
user="user1"

# Массив для хранения суммарного времени по месяцам
declare -A monthly_time
declare -A daily_count

# Чтение файла и обработка данных
while IFS=', ' read -r date username time; do
    # Проверка на соответствие пользователю
    if [[ "$username" == "$user" ]]; then
        month=$(date -d "$date" +%Y-%m) # Получаем год и месяц
        day=$(date -d "$date" +%Y-%m-%d) # Получаем полный день

        # Суммируем время по месяцам
        monthly_time[$month]=$(echo "${monthly_time[$month]:-0} + $time" | bc)

        # Увеличиваем счетчик дней
        daily_count[$month]=$((${daily_count[$month]:-0} + 1))
    fi
done < "$log_file"

# Вывод результатов
echo "Среднее процессорное время за день для пользователя $user:"
for month in "${!monthly_time[@]}"; do
    total_time=${monthly_time[$month]}
    total_days=${daily_count[$month]}
    average_time=$(echo "$total_time / $total_days" | bc -l)
    echo "$month: $average_time"
done

# Рассчитываем общее среднее за весь период
total_time=0
total_days=0
for month in "${!monthly_time[@]}"; do
    total_time=$(echo "$total_time + ${monthly_time[$month]}" | bc)
    total_days=$(echo "$total_days + ${daily_count[$month]}" | bc)
done

overall_average=$(echo "$total_time / $total_days" | bc -l)
echo "Общее среднее процессорное время за день: $overall_average"
