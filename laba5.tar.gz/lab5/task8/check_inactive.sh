#!/bin/bash

# Файл с пользователями
passwd_file="/etc/passwd"
# Файл с последними входами
lastlog_file="/var/log/lastlog"

# Массив для хранения пользователей и их последней даты доступа
declare -A user_last_login

# Чтение файла lastlog и извлечение информации о последнем входе
while IFS= read -r line; do
    user=$(echo "$line" | awk '{print $1}')
    last_login=$(echo "$line" | awk '{print $3, $4, $5, $6, $7}')
    
    # Сохраняем информацию о пользователе и дате последнего входа
    if [[ -n "$user" ]]; then
        user_last_login["$user"]="$last_login"
    fi
done < <(lastlog)

# Список пользователей, не работавших в апреле
echo "Пользователи, не работавшие в апреле с указанием последней даты доступа:"
for user in $(cut -d: -f1 "$passwd_file"); do
    last_login="${user_last_login[$user]}"
    
    # Проверяем, была ли последняя дата входа в апреле
    if [[ -z "$last_login" || ! "$last_login" =~ "Apr" ]]; then
        echo "$user: Последний вход - $last_login"
    fi
done
