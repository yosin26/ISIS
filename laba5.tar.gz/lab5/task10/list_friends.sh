#!/bin/bash

# Файл со списком пользователей
user_list="u1-list"

# Проверка наличия файла
if [[ ! -f "$user_list" ]]; then
    echo "Файл $user_list не найден!"
    exit 1
fi

# Массив для хранения пользователей группы friends
friends_users=()
total_users=0

# Чтение файла со списком пользователей
while IFS= read -r user; do
    # Увеличиваем общий счетчик пользователей
    ((total_users++))
    
    # Получаем группы пользователя
    if groups "$user" | grep -q '\bfriends\b'; then
        friends_users+=("$user")
    fi
done < "$user_list"

# Вывод списка пользователей группы friends
echo "Пользователи группы 'friends':"
for friend in "${friends_users[@]}"; do
    echo "$friend"
done

# Рассчитываем процент
if [[ $total_users -gt 0 ]]; then
    friends_count=${#friends_users[@]}
    percentage=$(echo "scale=2; ($friends_count / $total_users) * 100" | bc)
    echo "Процент пользователей группы 'friends': $percentage%"
else
    echo "Нет пользователей в списке."
fi
