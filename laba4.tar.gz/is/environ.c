#include <stdio.h>
#include <stddef.h>

extern char **environ;

int main(int argc, char *argv[]) {
    int i;

    printf("число параметров, переданных программе %s равно %d\n", argv[0], argc - 1);
    
    for (i = 1; i < argc; i++) {
        printf("argv[%d] = %s\n", i, argv[i]);
    }

    for (i = 0; environ[i] != NULL; i++) {
        printf("environ[%d] : %s\n", i, environ[i]);
    }

    return 0;
}
