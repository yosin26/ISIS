#include <stdio.h>            // Для printf
#include <sys/types.h>       // Для основных типов
#include <sys/stat.h>        // Для структуры stat
#include <unistd.h>          // Для lstat
#include <time.h>            // Для ctime
#include <fcntl.h>           // Для major/minor
#include <stdlib.h>          // Для exit
#include <sys/sysmacros.h>   // Для major/minor

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Использование: %s <имя файла>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    struct stat s;
    char *ptype;

    // Получение информации о файле
    if (lstat(argv[1], &s) == -1) {
        perror("Ошибка при получении информации о файле");
        exit(EXIT_FAILURE);
    }

    // Определение типа файла
    if (S_ISREG(s.st_mode))
        ptype = "Обычный файл";
    else if (S_ISDIR(s.st_mode))
        ptype = "Каталог";    
    else if (S_ISLNK(s.st_mode))
        ptype = "Символическая связь";    
    else if (S_ISCHR(s.st_mode))
        ptype = "Символьное устройство";    
    else if (S_ISBLK(s.st_mode))
        ptype = "Блочное устройство";    
    else if (S_ISSOCK(s.st_mode))
        ptype = "Сокет";    
    else if (S_ISFIFO(s.st_mode))
        ptype = "FIFO";    
    else
        ptype = "Неизвестный тип";    

    // Вывод информации о файле:
    // Тип    
    printf("type = %s\n", ptype);
    // Права доступа    
    printf("perm = %o\n", s.st_mode & 0x1FF);
    // Номер inode    
    printf("inode = %lu\n", s.st_ino);
    // Число связей
    printf("nlink = %lu\n", s.st_nlink);
    // Устройство, на котором хранится данный файл
    printf("dev = (%d, %d)\n", major(s.st_dev), minor(s.st_dev));
    // Владельцы файла
    printf("UID = %d\n", s.st_uid);
    printf("GID = %d\n", s.st_gid);
    // Для специальных файлов устройств - номера устройства    
    printf("rdev = (%d, %d)\n", major(s.st_rdev), minor(s.st_rdev));
    // Размер файла
    printf("size = %ld\n", s.st_size);
    // Время доступа, модификации и модификации метаданных
    printf("atime = %s", ctime(&s.st_atime));
    printf("mtime = %s", ctime(&s.st_mtime));
    printf("ctime = %s", ctime(&s.st_ctime));

    return 0;
}
