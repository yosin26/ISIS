#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <unistd.h>

#define SHM_SIZE 1024  // Размер разделяемой памяти
#define SEM_KEY 1234   // Ключ для семафора
#define SHM_KEY 5678   // Ключ для разделяемой памяти

void P(int semid) {
    struct sembuf sb = {0, -1, 0};
    semop(semid, &sb, 1);
}

void V(int semid) {
    struct sembuf sb = {0, 1, 0};
    semop(semid, &sb, 1);
}

int main() {
    int shmid = shmget(SHM_KEY, SHM_SIZE, 0666);
    char *shm_ptr = shmat(shmid, NULL, 0);

    // Получение семафора
    int semid = semget(SEM_KEY, 1, 0666);

    // Чтение данных из разделяемой памяти
    P(semid);  // Захват семафора
    printf("Сообщение от сервера: %s", shm_ptr);
    V(semid);  // Освобождение семафора

    // Отключение от разделяемой памяти
    shmdt(shm_ptr);
    return 0;
}
