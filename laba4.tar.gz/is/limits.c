#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
    int fd_src, fd_dst;
    caddr_t addr_src, addr_dst;
    struct stat filestat;

    // Проверка количества аргументов
    if (argc != 3) {
        fprintf(stderr, "Использование: %s <исходный файл> <целевой файл>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Открытие исходного файла
    fd_src = open(argv[1], O_RDONLY);
    if (fd_src < 0) {
        perror("Ошибка открытия исходного файла");
        exit(EXIT_FAILURE);
    }

    // Открытие целевого файла
    fd_dst = open(argv[2], O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if (fd_dst < 0) {
        perror("Ошибка открытия целевого файла");
        close(fd_src);
        exit(EXIT_FAILURE);
    }

    // Определение размера исходного файла
    if (fstat(fd_src, &filestat) < 0) {
        perror("Ошибка получения информации о файле");
        close(fd_src);
        close(fd_dst);
        exit(EXIT_FAILURE);
    }

    // Делаем размер целевого файла равным исходному файлу
    if (lseek(fd_dst, filestat.st_size - 1, SEEK_SET) < 0) {
        perror("Ошибка перемещения в целевом файле");
        close(fd_src);
        close(fd_dst);
        exit(EXIT_FAILURE);
    }
    write(fd_dst, "", 1); // Убедимся, что файл имеет нужный размер

    // Задаем отображение в память
    addr_src = mmap(NULL, filestat.st_size, PROT_READ, MAP_SHARED, fd_src, 0);
    if (addr_src == MAP_FAILED) {
        perror("Ошибка отображения исходного файла в память");
        close(fd_src);
        close(fd_dst);
        exit(EXIT_FAILURE);
    }

    addr_dst = mmap(NULL, filestat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_dst, 0);
    if (addr_dst == MAP_FAILED) {
        perror("Ошибка отображения целевого файла в память");
        munmap(addr_src, filestat.st_size);
        close(fd_src);
        close(fd_dst);
        exit(EXIT_FAILURE);
    }

    // Копируем области памяти
    memcpy(addr_dst, addr_src, filestat.st_size);

    // Освобождение ресурсов
    munmap(addr_src, filestat.st_size);
    munmap(addr_dst, filestat.st_size);
    close(fd_src);
    close(fd_dst);

    return 0;
}
