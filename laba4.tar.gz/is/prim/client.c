#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#define CHAN1 "/tmp/fifo1"
#define CHAN2 "/tmp/fifo2"
#define MAXBUFF 1024

int main() {
    int fdw, fdr;
    char buff[MAXBUFF];

    // Открытие именованных каналов
    if ((fdw = open(CHAN1, O_WRONLY)) < 0) {
        perror("client: can't open write fifo");
        exit(1);
    }
    if ((fdr = open(CHAN2, O_RDONLY)) < 0) {
        perror("client: can't open read fifo");
        exit(1);
    }

    // Ввод имени файла
    printf("Введите имя файла для чтения: ");
    fgets(buff, MAXBUFF, stdin);
    buff[strcspn(buff, "\n")] = 0; // Удаление символа новой строки

    // Отправка имени файла серверу
    write(fdw, buff, strlen(buff) + 1);

    // Чтение ответа от сервера
    while (read(fdr, buff, MAXBUFF) > 0) {
        printf("%s", buff);
    }

    close(fdw);
    close(fdr);
    return 0;
}
