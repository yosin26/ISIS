#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define CHAN1 "/tmp/fifo1"
#define CHAN2 "/tmp/fifo2"
#define PERM 0666
#define MAXBUFF 1024

void server(int fdr, int fdw) {
    char buff[MAXBUFF];
    char err[256];
    int n, fd;

    printf("SERVER\n");

    // Чтение имени файла из канала
    if ((n = read(fdr, buff, MAXBUFF)) <= 0) {
        perror("server: filename read error");
        return;
    }
    buff[n] = '\0'; // Завершение строки

    // Попытка открыть файл
    if ((fd = open(buff, O_RDONLY)) < 0) {
        // Отправка сообщения об ошибке клиенту
        sprintf(err, "can't open %s\n", buff);
        strcat(buff, err);
        n = strlen(buff);
        if (write(fdw, buff, n) != n) {
            perror("server: error message write error");
        }
    } else {
        // Чтение данных из файла и запись их в канал
        while ((n = read(fd, buff, MAXBUFF)) > 0) {
            if (write(fdw, buff, n) != n) {
                perror("server: data write error");
            }
            // Вывод данных на экран
            if (write(1, buff, n) != n) {
                perror("server: data write error to stdout");
            }
        }
        if (n < 0) {
            perror("server: data read error");
        }
        close(fd); // Закрытие файла
    }
}

int main() {
    int fdr, fdw;

    // Создание именованных каналов
    if ((mkfifo(CHAN1, PERM) < 0) && (errno != EEXIST)) {
        perror("Can't create fifo 1");
        exit(1);
    }
    if ((mkfifo(CHAN2, PERM) < 0) && (errno != EEXIST)) {
        unlink(CHAN1);
        perror("Can't create fifo 2");
        exit(1);
    }

    // Открытие именованных каналов
    if ((fdr = open(CHAN1, O_RDONLY)) < 0) {
        perror("server: can't open read fifo");
        exit(1);
    }
    if ((fdw = open(CHAN2, O_WRONLY)) < 0) {
        perror("server: can't open write fifo");
        exit(1);
    }

    server(fdr, fdw);

    close(fdr);
    close(fdw);
    return 0;
}
